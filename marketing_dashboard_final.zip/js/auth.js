
function login() {
  const email = email.value;
  const password = document.getElementById("password").value;

  auth.signInWithEmailAndPassword(email, password)
  .then(async (res)=>{
    const doc = await db.collection("users").doc(res.user.uid).get();
    const role = doc.data().role;

    if(role==="admin") window.location="dashboard.html";
    else window.location="report.html";
  })
  .catch(e=>alert(e.message));
}
