
auth.onAuthStateChanged(async user=>{
  if(!user) location="index.html";
});

function submitReport(){
  const user = auth.currentUser;

  db.collection("users").doc(user.uid).get().then(doc=>{
    const name = doc.data().name;

    db.collection("reports").add({
      userId:user.uid,
      name:name,
      date:date.value,
      totalCalling:+totalCalling.value,
      connectedCalls:+connectedCalls.value,
      positiveCalls:+positiveCalls.value,
      doorVisiting:+doorVisiting.value,
      closedAdmission:+closedAdmission.value
    }).then(()=>alert("Submitted"));
  });
}
