
auth.onAuthStateChanged(async user=>{
  if(!user) location="index.html";

  const doc = await db.collection("users").doc(user.uid).get();
  if(doc.data().role!=="admin"){
    alert("Access denied");
    location="index.html";
  }
});

async function loadData(){
  const dateFilter = document.getElementById("filterDate").value;
  const snap = await db.collection("reports").get();

  let calls=0, visits=0, admissions=0;
  let emp={};

  snap.forEach(doc=>{
    const d = doc.data();

    if(dateFilter && d.date!==dateFilter) return;

    calls+=d.totalCalling;
    visits+=d.doorVisiting;
    admissions+=d.closedAdmission;

    emp[d.name]=(emp[d.name]||0)+d.totalCalling;
  });

  new Chart(callsChart,{type:'bar',
    data:{labels:["Calls"],datasets:[{label:"Total",data:[calls]}]}
  });

  new Chart(visitChart,{type:'bar',
    data:{labels:["Visits","Admissions"],datasets:[{data:[visits,admissions]}]}
  });

  new Chart(employeeChart,{
    type:'bar',
    data:{labels:Object.keys(emp),datasets:[{data:Object.values(emp)}]}
  });
}

loadData();
